/** An empty service worker! */

self.addEventListener('fetch', (event) => {

})
